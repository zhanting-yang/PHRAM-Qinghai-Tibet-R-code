# R Reproducibility Scripts

This folder contains complete R scripts to reproduce all statistical analyses and figures from the manuscript.

## Prerequisites

### Install R (>= 4.0 recommended)
Download from: https://cran.r-project.org/

### Install required packages

Open R or RStudio and run:

```r
install.packages(c(
  "tidyverse",   # ggplot2, dplyr, readr, etc.
  "broom",       # Tidy model outputs
  "lmtest",      # Robust standard errors
  "sandwich",    # HC3 heteroskedasticity-consistent SE
  "boot",        # Bootstrap resampling
  "psych",       # Descriptive statistics
  "corrplot",    # Correlation heatmaps
  "spdep",       # Spatial analysis
  "sf",          # Spatial data
  "mapchina",    # China map data (optional, for Figure 5)
  "patchwork",   # Multi-panel figures
  "cowplot",     # Plot utilities
  "jsonlite"     # JSON export
))
```

## Quick Start

### Option 1: Run everything at once

```r
# Set working directory to r_scripts folder
setwd("D:/your_path/reproducibility/r_scripts")

# Run all analyses and generate all figures
source("run_all.R")
```

### Option 2: Run step by step

```r
setwd("D:/your_path/reproducibility/r_scripts")

# Step 1: Statistical analyses
source("01_analysis.R")

# Step 2-8: Generate figures one by one
source("02_figure1.R")  # Environmental epidemiology overview (6 panels)
source("03_figure2.R")  # Forest plot of provincial PAF
source("04_figure3.R")  # Black carbon analysis
source("05_figure4.R")  # Conceptual framework
source("06_figure5.R")  # China provincial heatmap
source("07_figure6.R")  # Mediation pathway + scatter
source("08_figure7.R")  # Moran's I permutation distributions
```

## Script Overview

| Script | Output | Description |
|--------|--------|-------------|
| `01_analysis.R` | `r_output/*.csv`, `*.json`, `*.rds` | All statistical analyses: cluster, correlation, regression, mediation, spatial autocorrelation |
| `02_figure1.R` | `Figure1_*.png` | 6-panel overview: scatter + LOESS, correlation heatmap, box plots |
| `03_figure2.R` | `Figure2_*.png` | Forest plot: PM2.5 vs Household PAF for all 31 provinces |
| `04_figure3.R` | `Figure3_*.png` | BC concentration, BC fraction, BC/OC ratio (4 provinces) |
| `05_figure4.R` | `Figure4_*.png` | Conceptual framework: exposure vs susceptibility pathways |
| `06_figure5.R` | `Figure5_*.png` | China map heatmap: Total PAF bubble plot |
| `07_figure6.R` | `Figure6_*.png` | Mediation pathway diagram + COPD DALY vs elevation scatter |
| `08_figure7.R` | `Figure7_*.png` | Moran's I permutation distributions (3 panels) |

## Key Reproduced Statistics

### Table 1: Cluster Descriptives
- Lowland: n=16, mean elevation ~309m
- Mid-elevation: n=11, mean elevation ~658m
- High-elevation: n=4, mean elevation ~3027m

### Correlations (Spearman)
- Elevation vs PM2.5 PAF: r = -0.404, p = 0.024
- Elevation vs Household PAF: r = +0.745, p < 0.001

### Robust Regression (HC3)
- Elevation: standardized beta = 0.438, p < 0.001
- Urbanization: standardized beta = -0.638, p = 0.004

### Mediation Analysis
- Path a = 0.412, Path b = 0.548
- Indirect effect = +0.226, Bootstrap 95% CI: [0.015, 0.546]
- Proportion mediated = 49.5%
- Sobel test: z = 1.53, p = 0.126

### Spatial Autocorrelation (Moran's I, k=4, 999 permutations)
- Household PAF: I = 0.459, p = 0.003
- PM2.5 PAF: I = 0.418, p = 0.002
- Total PAF: I = 0.457, p = 0.001

## Figure Customization

All figures are generated with `ggplot2` and can be easily customized:

```r
# Example: Change color scheme
fig_custom <- fig1 + scale_color_viridis_d()

# Example: Change dimensions
ggsave("my_figure.png", fig_custom, width = 12, height = 8, dpi = 300)
```

## Troubleshooting

### Package not found
```r
# For a specific missing package
install.packages("package_name")
```

### Figure 5 (China map) issues
If `maps`/`mapdata` packages are not available, Figure 5 will fall back to a scatter plot on lat/lon coordinates. To get the full provincial boundary map:

```r
install.packages(c("maps", "mapdata"))
```

Alternatively, use `sf` with a downloaded GeoJSON:
```r
library(sf)
china <- st_read("china_provinces.geojson")
```

### Path issues on Windows
If your path contains Chinese characters or spaces, copy the `reproducibility` folder to a simple path like `D:/reproduce/` before running.

## Citation

If you use these scripts, please cite the manuscript:

> Yang Z, et al. (2024). Correcting the High-Altitude Blind Spot in Environmental Health Risk Assessment: A 'Hidden Burden' Framework for the Qinghai-Tibet Plateau. *Environment International* (submitted).
