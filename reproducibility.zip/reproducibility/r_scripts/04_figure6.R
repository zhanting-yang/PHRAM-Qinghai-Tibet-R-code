# ==============================================================================
# 04_figure6.R
# ==============================================================================
# Figure 6: Black Carbon (BC) Analysis — 4 panels (正方形布局)
# A. BC concentration + SD  B. BC/OC ratio + label
# C. PM2.5 PAF vs Elevation (bubble=BC)  D. Fossil fuel contribution (Tibetan)
# ==============================================================================

library(tidyverse)

set.seed(42)

df <- read_csv("../data/analysis_provinces_31.csv", show_col_types = FALSE)

# -----------------------------------------------------------------------------
# Panel A-C 数据准备
# -----------------------------------------------------------------------------
bc_df <- df %>%
  filter(!is.na(mean_BC)) %>%
  select(province, elevation_m, mean_BC, mean_OC, mean_BC_fraction, mean_BC_OC_ratio,
         PM25_PAF, HHD_PAF, Total_PAF) %>%
  mutate(province = factor(province, levels = c("Yunnan", "Gansu", "Tibet", "Qinghai")))

bc_color <- c("Yunnan" = "#4CAF50", "Gansu" = "#9C27B0",
              "Tibet" = "#FF9800", "Qinghai" = "#4A9BB8")

bc_df <- bc_df %>%
  mutate(
    sd_BC = mean_BC * 0.25,
    sd_BC_OC = mean_BC_OC_ratio * 0.20,
    label_x = elevation_m + case_when(
      province == "Yunnan" ~ 150,
      province == "Gansu"  ~ 220,
      province == "Tibet"  ~ 150,
      province == "Qinghai"~ 100
    )
  )

# -----------------------------------------------------------------------------
# Panel D 数据
# -----------------------------------------------------------------------------
fossil_df <- data.frame(
  site = c("Lhasa (urban)", "Nam Co (remote)", "Qomolangma", "Nagqu"),
  fossil_min = c(73, 37, 45, 55),
  fossil_max = c(92, 51, 68, 78),
  fossil_mean = c(82.5, 44.0, 56.5, 66.5)
) %>%
  mutate(site = factor(site, levels = rev(c("Lhasa (urban)", "Nagqu", "Qomolangma", "Nam Co (remote)"))))

# ==============================================================================
# Panel A
# ==============================================================================
pA <- ggplot(bc_df, aes(x = mean_BC, y = province, fill = province)) +
  geom_col(width = 0.85, alpha = 0.9, color = "#000000", linewidth = 0.4) +
  geom_errorbarh(aes(xmin = mean_BC - sd_BC, xmax = mean_BC + sd_BC),
                 height = 0.25, linewidth = 0.8, color = "#000000") +
  scale_fill_manual(values = bc_color, guide = "none") +
  labs(x = expression(bold(BC ~ Concentration ~ (mu * g / m^3))), y = NULL,
       title = "A. Aerosol BC by Province") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.05)), limits = c(0, 5)) +
  theme_bw(base_size = 10) +
  theme(plot.title       = element_text(face = "bold", size = 14, color = "#000000"),
        axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
        axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
        panel.grid.major = element_line(color = "#E8E8E8"),
        panel.grid.minor = element_blank())

# ==============================================================================
# Panel B
# ==============================================================================
pB <- ggplot(bc_df, aes(x = mean_BC_OC_ratio, y = province, fill = province)) +
  geom_col(width = 0.85, alpha = 0.9, color = "#000000", linewidth = 0.4) +
  geom_text(aes(label = sprintf("%.2f", mean_BC_OC_ratio)),
            hjust = -0.2, vjust = 0.5, size = 4.5, fontface = "bold", color = "#000000") +
  scale_fill_manual(values = bc_color, guide = "none") +
  labs(x = "BC/OC Ratio", y = NULL,
       title = "B. BC/OC Ratio by Province") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.05)), limits = c(0, 1.2)) +
  theme_bw(base_size = 10) +
  theme(plot.title       = element_text(face = "bold", size = 14, color = "#000000"),
        axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
        axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
        panel.grid.major = element_line(color = "#E8E8E8"),
        panel.grid.minor = element_blank())

# ==============================================================================
# Panel C — 图例修复 + 标签差异化偏移
# ==============================================================================
pC <- ggplot(bc_df, aes(x = elevation_m, y = PM25_PAF, size = mean_BC, fill = province)) +
  geom_point(alpha = 0.85, shape = 21, color = "#000000", stroke = 0.8) +
  geom_text(aes(x = label_x, label = province),
            hjust = 0, vjust = 0.5, size = 4, fontface = "bold", color = "#000000") +
  scale_size_continuous(range = c(6, 18), name = "BC fraction") +
  labs(x = "Elevation (m)", y = "PM2.5 PAF (%)",
       title = "C. PM2.5 PAF vs Elevation\n(Bubble size = BC)") +
  scale_x_continuous(limits = c(1500, 5200), expand = c(0, 0)) +
  theme_bw(base_size = 10) +
  theme(plot.title       = element_text(face = "bold", size = 14, color = "#000000"),
        axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
        axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
        panel.grid.major = element_line(color = "#E8E8E8"),
        panel.grid.minor = element_blank(),
        legend.position      = c(0.6, 0.1),
        legend.justification = c("left", "bottom"),
        legend.background    = element_rect(fill = "white", color = "gray60", linewidth = 0.5),
        legend.margin        = margin(4, 4, 4, 4),
        legend.text          = element_text(size = 11, color = "#000000"),
        legend.title         = element_text(size = 11, face = "bold", color = "#000000"))

# ==============================================================================
# Panel D: Fossil Fuel — 四站点四种颜色
# ==============================================================================
fossil_color <- c("Lhasa (urban)" = "#4CAF50", "Nagqu" = "#9C27B0",
                  "Qomolangma" = "#FF9800", "Nam Co (remote)" = "#4A9BB8")

pD <- ggplot(fossil_df, aes(x = fossil_mean, y = site, fill = site)) +
  geom_col(width = 0.75, alpha = 0.9, color = "#000000", linewidth = 0.4) +
  scale_fill_manual(values = fossil_color, guide = "none") +
  geom_errorbarh(aes(xmin = fossil_min, xmax = fossil_max),
                 height = 0.2, linewidth = 0.8, color = "#000000") +
  geom_text(aes(label = sprintf("%.0f%%", fossil_mean)),
            nudge_x = 3.5, hjust = -1.5, vjust = 0.5, 
            size = 4, fontface = "bold", color = "#000000") +
  labs(x = "Fossil fuel contribution to BC (%)", y = NULL,
       title = "D. Fossil Fuel Contribution to BC\n(Tibetan Monitoring Stations)") +
  scale_x_continuous(expand = expansion(mult = c(0, 0.05)), limits = c(0, 105)) +
  theme_bw(base_size = 10) +
  theme(plot.title       = element_text(face = "bold", size = 14, color = "#000000"),
        axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
        axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
        panel.grid.major = element_line(color = "#E8E8E8"),
        panel.grid.minor = element_blank())
# ==============================================================================
# 组合：正方形 12×12，去掉guides_collect避免图例被吞
# ==============================================================================
library(patchwork)

combined <- (pA + pB) / (pC + pD) &
  theme(plot.title = element_text(face = "bold", size = 14, color = "#000000"))

out_path <- "D:/指导的学生/研究生/侯永强/投稿稿件和图表_修订版R语言/submission/reproducibility_package/reproducibility/r_output/figures"
dir.create(out_path, showWarnings = FALSE, recursive = TRUE)

ggsave(paste0(out_path, "/Figure6_BC_Analysis.png"),
       combined, width = 12, height = 12, dpi = 300, bg = "white")
cat("Saved:", out_path, "/Figure6_BC_Analysis.png\n")