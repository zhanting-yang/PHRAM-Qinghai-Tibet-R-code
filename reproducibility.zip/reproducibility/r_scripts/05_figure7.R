# ==============================================================================
# 05_figure7.R
# ==============================================================================
# Figure 7: Conceptual Summary Framework
# Shows the two underestimation pathways: exposure vs. susceptibility
# 修改：
#   1. 图例增大区域，改为两行排列，彻底避免文字与线条重叠
#   2. 底部虚线箭头精确指向绿色框上边缘
#   3. 标题颜色统一为纯黑
# ==============================================================================

library(tidyverse)

fig4 <- ggplot() +
  coord_cartesian(xlim = c(0, 10), ylim = c(0, 10)) +
  theme_void() +
  # Title
  annotate("text", x = 5, y = 9.5,
           label = "Figure 4. Conceptual Framework:\nThe 'Hidden Burden' of Air Pollution at High Altitude",
           size = 5, fontface = "bold", hjust = 0.5, color = "#000000") +
  # Central box: High Altitude
  annotate("rect", xmin = 3.5, xmax = 6.5, ymin = 6.5, ymax = 8,
           fill = "#E3F2FD", color = "#1565C0", linewidth = 1) +
  annotate("text", x = 5, y = 7.25,
           label = "High Altitude\n(Cold Climate)",
           size = 5, fontface = "bold", color = "#1565C0") +
  # Left pathway: Exposure Underestimation
  annotate("rect", xmin = 0.3, xmax = 3, ymin = 3.5, ymax = 5.5,
           fill = "#FFF3E0", color = "#E65100", linewidth = 1) +
  annotate("text", x = 1.65, y = 4.8,
           label = "EXPOSURE\nUNDERESTIMATION",
           size = 5, fontface = "bold", color = "#E65100") +
  annotate("text", x = 1.65, y = 4.0,
           label = "Ambient-PM2.5-centric\npolicies ignore\nindoor solid fuel\n(dominate at altitude)",
           size = 3.5, color = "#333333", lineheight = 1.1) +
  # Right pathway: Susceptibility Underestimation
  annotate("rect", xmin = 7, xmax = 9.7, ymin = 3.5, ymax = 5.5,
           fill = "#FCE4EC", color = "#C62828", linewidth = 1) +
  annotate("text", x = 8.35, y = 4.8,
           label = "SUSCEPTIBILITY\nUNDERESTIMATION",
           size = 5, fontface = "bold", color = "#C62828") +
  annotate("text", x = 8.35, y = 4.0,
           label = "GBD functions calibrated\non lowland populations;\nhypoxia may amplify\nper-unit risk (hypothesis)",
           size = 3.5, color = "#333333", lineheight = 1.1) +
  # Bottom: Hidden Burden
  annotate("rect", xmin = 3, xmax = 7, ymin = 1, ymax = 2.5,
           fill = "#E8F5E9", color = "#2E7D32", linewidth = 1) +
  annotate("text", x = 5, y = 1.75,
           label = "HIDDEN BURDEN:\nTotal air pollution disease > national average\nin Tibet (7.97%) and Qinghai (7.98%)",
           size = 5, fontface = "bold", color = "#2E7D32", lineheight = 1.1) +
  # Arrows: 顶部实线箭头
  annotate("segment", x = 4.5, xend = 2.5, y = 6.5, yend = 5.5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#E65100", linewidth = 1.2) +
  annotate("segment", x = 5.5, xend = 7.5, y = 6.5, yend = 5.5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#C62828", linewidth = 1.2) +
  # Arrows: 底部虚线箭头（指向绿色框上边缘中点两侧）
  annotate("segment", x = 2.5, xend = 3.8, y = 3.5, yend = 2.5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#E65100", linewidth = 0.8, linetype = "dashed") +
  annotate("segment", x = 7.5, xend = 6.2, y = 3.5, yend = 2.5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#C62828", linewidth = 0.8, linetype = "dashed") +
  # Legend box（增大区域，两行排列避免重叠）
  annotate("rect", xmin = 0.2, xmax = 3.5, ymin = 0.1, ymax = 0.9,
           fill = "white", color = "gray60", linewidth = 0.5) +
  # Documented pathway（第一行）
  annotate("segment", x = 0.5, xend = 1.5, y = 0.65, yend = 0.65,
           color = "#E65100", linewidth = 1.5) +
  annotate("text", x = 1.6, y = 0.65,
           label = "Documented pathway", size = 2.8, color = "#333333", hjust = 0) +
  # Hypothesized pathway（第二行）
  annotate("segment", x = 0.5, xend = 1.5, y = 0.35, yend = 0.35,
           color = "#C62828", linewidth = 1.5, linetype = "dashed") +
  annotate("text", x = 1.6, y = 0.35,
           label = "Hypothesized pathway", size = 2.8, color = "#333333", hjust = 0)

# Save
out_path <- "D:/指导的学生/研究生/侯永强/投稿稿件和图表_修订版R语言/submission/reproducibility_package/reproducibility/r_output/figures"
dir.create(out_path, showWarnings = FALSE, recursive = TRUE)

ggsave(paste0(out_path, "/Figure7_Conceptual_Summary.png"),
       fig4, width = 12, height = 8, dpi = 300, bg = "white")
cat("Saved:", out_path, "/Figure7_Conceptual_Summary.png\n")