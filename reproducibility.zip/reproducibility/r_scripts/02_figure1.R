# ==============================================================================
# 02_figure1.R
# ==============================================================================
# 修改：
#   1. D-F保留箱线图 + Mean±SD误差线（保留两端横线）
#   2. D-F均值用黑色散点（shape=16实心圆）标记
#   3. "China avg"：纯黑、加粗、右移1.5cm（x=4.5）、单行、小四
#   4. B图r/p值右移2cm
# ==============================================================================

library(tidyverse)

set.seed(42)

# ------------------------------------------------------------------------------
# LOAD DATA
# ------------------------------------------------------------------------------
df <- read_csv("../data/analysis_provinces_31.csv", show_col_types = FALSE)

lowland_provs <- c("Shanghai", "Tianjin", "Zhejiang", "Beijing", "Jiangsu", "Hainan",
                   "Guangdong", "Fujian", "Hubei", "Hunan", "Shandong", "Hebei",
                   "Ningxia", "Jilin", "Liaoning", "Shanxi")
mid_provs <- c("Shaanxi", "Henan", "Anhui", "Inner Mongolia", "Heilongjiang",
               "Jiangxi", "Chongqing", "Sichuan", "Xinjiang", "Guangxi", "Guizhou")
high_provs <- c("Yunnan", "Gansu", "Tibet", "Qinghai")

df <- df %>%
  mutate(cluster_label = case_when(
    province %in% lowland_provs ~ "Lowland",
    province %in% mid_provs ~ "Mid-elevation",
    province %in% high_provs ~ "High-elevation"
  ),
  cluster_label = factor(cluster_label,
                         levels = c("Lowland", "Mid-elevation", "High-elevation")))

cluster_colors <- c("Lowland" = "#4CAF50", "Mid-elevation" = "#9C27B0", "High-elevation" = "#FF9800")

theme_custom <- function() {
  theme_bw(base_size = 10) +
    theme(
      axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
      axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
      plot.title       = element_text(face = "bold", size = 11),
      panel.grid.major = element_line(color = "#E0E0E0"),
      panel.grid.minor = element_blank()
    )
}

# ------------------------------------------------------------------------------
# BUILD FIGURE
# ------------------------------------------------------------------------------
fig1 <- function() {

  # --- Panel A: PM2.5 vs Elevation（r/p右移1cm）---
  pA <- ggplot(df, aes(x = elevation_m, y = PM25_PAF, color = cluster_label)) +
    geom_point(size = 3, alpha = 0.85) +
    geom_smooth(method = "loess", se = FALSE, color = "black", linetype = "dashed", linewidth = 0.8) +
    scale_color_manual(values = cluster_colors) +
    labs(x = "Elevation (m)", y = "PM2.5 PAF (%)", title = "A. Ambient PM2.5 PAF vs. Elevation") +
    annotate("text", x = min(df$elevation_m) + 800, y = max(df$PM25_PAF),
             label = sprintf("Spearman r = %.3f\np = %.3f",
                             cor(df$elevation_m, df$PM25_PAF, method = "spearman"),
                             cor.test(df$elevation_m, df$PM25_PAF, method = "spearman")$p.value),
             hjust = 0, vjust = 1, size = 3.5,
             color = "black", fontface = "bold") +
    theme_custom() +
    theme(legend.position = "none")

  # --- Panel B: Household PAF vs Elevation（r/p右移2cm）---
  pB <- ggplot(df, aes(x = elevation_m, y = HHD_PAF, color = cluster_label)) +
    geom_point(size = 3, alpha = 0.85) +
    geom_smooth(method = "loess", se = FALSE, color = "black", linetype = "dashed", linewidth = 0.8) +
    scale_color_manual(values = cluster_colors) +
    labs(x = "Elevation (m)", y = "Household Solid Fuel PAF (%)", title = "B. Household PAF vs. Elevation") +
    annotate("text", x = min(df$elevation_m) + 1600, y = min(df$HHD_PAF),
             label = sprintf("Spearman r = %.3f\np < 0.001",
                             cor(df$elevation_m, df$HHD_PAF, method = "spearman")),
             hjust = 0, vjust = 0, size = 3.5,
             color = "black", fontface = "bold") +
    theme_custom() +
    theme(legend.position = "none")

  # --- Panel C: Correlation heatmap ---
  corr_vars <- c("elevation_m", "PM25_PAF", "HHD_PAF", "Total_PAF")
  corr_labels <- c("Elevation", "PM2.5 PAF", "Household PAF", "Total PAF")
  corr_mat <- cor(df[, corr_vars], method = "spearman", use = "complete.obs")
  colnames(corr_mat) <- rownames(corr_mat) <- corr_labels

  corr_df <- as.data.frame(corr_mat) %>%
    rownames_to_column("var1") %>%
    pivot_longer(-var1, names_to = "var2", values_to = "value")

  pC <- ggplot(corr_df, aes(x = var2, y = var1, fill = value)) +
    geom_tile(color = "white", linewidth = 0.5) +
    geom_text(aes(label = sprintf("%.2f", value), color = abs(value) > 0.5),
              size = 3.5, fontface = "bold") +
    scale_fill_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                         midpoint = 0, limits = c(-1, 1), name = "Spearman r") +
    scale_color_manual(values = c("black", "white"), guide = "none") +
    labs(x = NULL, y = NULL, title = "C. Spearman Correlation Matrix") +
    theme_minimal(base_size = 10) +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 14, face = "bold", color = "#000000"),
          axis.text.y = element_text(size = 14, face = "bold", color = "#000000"),
          plot.title  = element_text(face = "bold", size = 11))

  # --- Panels D-F: 箱线图 + SD误差线（保留横线）+ 散点标记均值 ---
  make_box <- function(var, title, ylab) {
    nat_mean <- mean(df[[var]], na.rm = TRUE)

    summary_df <- df %>%
      group_by(cluster_label) %>%
      summarise(
        mean_val = mean(.data[[var]], na.rm = TRUE),
        sd_val   = sd(.data[[var]], na.rm = TRUE),
        .groups  = "drop"
      )

    ggplot(df, aes(x = cluster_label, y = .data[[var]], fill = cluster_label)) +
      # 箱线图
      geom_boxplot(alpha = 0.7, outlier.shape = 21, outlier.size = 2) +
      # Mean ± SD 误差线（保留两端横线）
      geom_errorbar(data = summary_df,
                    aes(x = cluster_label, ymin = mean_val - sd_val, ymax = mean_val + sd_val),
                    width = 0.25, linewidth = 0.9, color = "#000000",
                    inherit.aes = FALSE) +
      # 均值散点（黑色实心圆）
      geom_point(data = summary_df,
                 aes(x = cluster_label, y = mean_val),
                 size = 3, shape = 16, color = "#000000",
                 inherit.aes = FALSE) +
      # 全国均值虚线
      geom_hline(yintercept = nat_mean, linetype = "dashed", color = "gray50", linewidth = 0.8) +
      # China avg：纯黑、加粗、右移1.5cm（x=3.5）、单行、小四
      annotate("text", x = 3, y = nat_mean + 0.1,
               label = sprintf("China avg: %.2f%%", nat_mean),
               size = 3.5, color = "#000000", fontface = "bold", hjust = 0.5) +
      scale_fill_manual(values = cluster_colors) +
      labs(x = NULL, y = ylab, title = title) +
      theme_custom() +
      theme(legend.position = "none")
  }

  pD <- make_box("PM25_PAF", "D. PM2.5 PAF by Cluster", "PM2.5 PAF (%)")
  pE <- make_box("HHD_PAF", "E. Household PAF by Cluster", "Household PAF (%)")
  pF <- make_box("Total_PAF", "F. Total PAF by Cluster", "Total PAF (%)")

  # --- Combine：图例右上 ---
  library(patchwork)

  legend_plot <- ggplot(df, aes(x = elevation_m, y = PM25_PAF, color = cluster_label)) +
    geom_point(size = 3) +
    scale_color_manual(values = cluster_colors,
                       name = NULL,
                       labels = c("Lowland (n=16)", "Mid-elevation (n=11)", "High-elevation (n=4)")) +
    theme_void() +
    theme(legend.position = "bottom") +
    guides(color = guide_legend(nrow = 1))

  legend_grob <- cowplot::get_legend(legend_plot)

  combined <- (pA + pB + pC) / (pD + pE + pF) +
    plot_layout(guides = "collect") &
    theme(legend.position      = c(0.98, 0.98),
          legend.justification = c("right", "top"),
          legend.text          = element_text(size = 10),
          legend.background    = element_rect(fill = "white", color = "gray80"),
          legend.margin        = margin(4, 4, 4, 4))

  # --- Save ---
  ggsave("D:/指导的学生/研究生/侯永强/投稿稿件和图表_修订版R语言/submission/reproducibility_package/reproducibility/r_output/figures/Figure1_Environmental_Epidemiology_Overview2.png",
         combined, width = 16, height = 10, dpi = 300, bg = "white")
  cat("Saved: Figure1_Environmental_Epidemiology_Overview2.png\n")
}

fig1()