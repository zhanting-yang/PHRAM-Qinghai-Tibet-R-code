# ==============================================================================
# 03_figure2.R
# ==============================================================================
# Figure 2: Forest Plot of Provincial PAF Estimates
# 修改：
#   1. 横纵坐标：小四加粗(14pt, bold)，纯黑
#   2. 删除最上方标题（title + subtitle）
#   3. 图例用颜色表示（Blue=PM2.5, Red=Household）
# ==============================================================================

library(tidyverse)

set.seed(42)

df <- read_csv("../data/analysis_provinces_31.csv", show_col_types = FALSE)

# Sort by Total PAF descending
df <- df %>% arrange(desc(Total_PAF))
df$province <- factor(df$province, levels = df$province)

# 创建长格式数据，用于图例映射
df_long <- bind_rows(
  df %>% select(province, PAF = PM25_PAF, PAF_lower = PM25_PAF_lower, PAF_upper = PM25_PAF_upper) %>% mutate(Type = "Ambient PM2.5"),
  df %>% select(province, PAF = HHD_PAF, PAF_lower = HHD_PAF_lower, PAF_upper = HHD_PAF_upper) %>% mutate(Type = "Household Solid Fuel")
)

df_long$Type <- factor(df_long$Type, levels = c("Ambient PM2.5", "Household Solid Fuel"))

# 颜色映射
type_colors <- c("Ambient PM2.5" = "#1565C0", "Household Solid Fuel" = "#C62828")

fig2 <- ggplot(df_long, aes(x = province, y = PAF, color = Type)) +
  # 误差线
  geom_errorbar(aes(ymin = PAF_lower, ymax = PAF_upper), width = 0.3, linewidth = 0.6) +
  # 普通省份点
  geom_point(data = df_long %>% filter(!(province %in% c("Tibet", "Qinghai"))),
             size = 2.5) +
  # Tibet和Qinghai高亮（空心圆+边框）
  geom_point(data = df_long %>% filter(province %in% c("Tibet", "Qinghai")),
             size = 4, shape = 21, fill = "white", stroke = 1.5) +
  # 全国均值虚线
  geom_hline(yintercept = mean(df$PM25_PAF), linetype = "dashed",
             color = "#1565C0", alpha = 0.5, linewidth = 0.6) +
  geom_hline(yintercept = mean(df$HHD_PAF), linetype = "dashed",
             color = "#C62828", alpha = 0.5, linewidth = 0.6) +
  # 颜色映射 + 图例
  scale_color_manual(values = type_colors, name = NULL) +
  # 删除标题，只保留y轴标签
  labs(x = NULL, y = "Population Attributable Fraction (%)") +
  coord_flip() +
  scale_y_continuous(limits = c(0, 8), breaks = seq(0, 8, 1)) +
  theme_bw(base_size = 11) +
  theme(
    plot.title       = element_blank(),
    plot.subtitle    = element_blank(),
    axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
    axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
    axis.text.y      = element_text(size = 14, face = "bold", color = "#000000"),
    panel.grid.minor = element_blank(),
    # 图例设置：放右上方
    legend.position      = c(0.98, 0.98),
    legend.justification = c("right", "top"),
    legend.text          = element_text(size = 12, face = "bold", color = "#000000"),
    legend.background    = element_rect(fill = "white", color = "gray80"),
    legend.margin        = margin(4, 4, 4, 4),
    legend.key           = element_rect(fill = "white", color = NA)
  )

# 保存（正斜杠路径）
out_path <- "D:/指导的学生/研究生/侯永强/投稿稿件和图表_修订版R语言/submission/reproducibility_package/reproducibility/r_output/figures"
dir.create(out_path, showWarnings = FALSE, recursive = TRUE)

ggsave(paste0(out_path, "/Figure2_Forest_Plot_Provincial_PAF.png"),
       fig2, width = 10, height = 12, dpi = 300, bg = "white")
cat("Saved:", out_path, "/Figure2_Forest_Plot_Provincial_PAF.png\n")