# ==============================================================================
# 01_analysis.R
# ==============================================================================
# R reproduction of all statistical analyses from the manuscript.
# Run this first before generating figures.
#
# Required packages:
#   install.packages(c("tidyverse", "broom", "lmtest", "sandwich", "boot",
#                      "psych", "corrplot", "spdep", "sf", "mapchina"))
# ==============================================================================

library(tidyverse)

set.seed(42)

# ------------------------------------------------------------------------------
# 1. LOAD DATA
# ------------------------------------------------------------------------------
df <- read_csv("../data/analysis_provinces_31.csv", show_col_types = FALSE)
cat("Loaded", nrow(df), "provinces\n")

# ------------------------------------------------------------------------------
# 2. CLUSTER ASSIGNMENT (manuscript-defined)
# ------------------------------------------------------------------------------
lowland_provs <- c("Shanghai", "Tianjin", "Zhejiang", "Beijing", "Jiangsu", "Hainan",
                   "Guangdong", "Fujian", "Hubei", "Hunan", "Shandong", "Hebei",
                   "Ningxia", "Jilin", "Liaoning", "Shanxi")
mid_provs <- c("Shaanxi", "Henan", "Anhui", "Inner Mongolia", "Heilongjiang",
               "Jiangxi", "Chongqing", "Sichuan", "Xinjiang", "Guangxi", "Guizhou")
high_provs <- c("Yunnan", "Gansu", "Tibet", "Qinghai")

df <- df %>%
  mutate(cluster_label = case_when(
    province %in% lowland_provs ~ "Lowland",
    province %in% mid_provs ~ "Mid-elevation",
    province %in% high_provs ~ "High-elevation"
  ),
  cluster_label = factor(cluster_label,
                         levels = c("Lowland", "Mid-elevation", "High-elevation")))

# Verify clusters
cat("\n=== CLUSTER ASSIGNMENT ===\n")
df %>%
  group_by(cluster_label) %>%
  summarise(n = n(), mean_elev = mean(elevation_m),
            min_elev = min(elevation_m), max_elev = max(elevation_m),
            .groups = "drop") %>%
  print()

# ------------------------------------------------------------------------------
# 3. TABLE 1: DESCRIPTIVE STATISTICS
# ------------------------------------------------------------------------------
cat("\n=== TABLE 1: DESCRIPTIVE STATISTICS ===\n")

vars_table1 <- list(
  elevation_m = "Elevation (m)",
  PM25_PAF = "PM2.5 PAF (%)",
  HHD_PAF = "Household PAF (%)",
  O3_PAF = "O3 PAF (%)",
  Total_PAF = "Total PAF (%)",
  mean_BC = "BC concentration (ug/m3)",
  mean_BC_fraction = "BC fraction (%)",
  COPD_DALY_rate = "COPD DALY rate",
  gdp_pc = "GDP per capita (10k CNY)",
  urban = "Urbanization (%)",
  beds_per_1000 = "Beds per 1000"
)

table1 <- map_dfr(names(vars_table1), function(var) {
  df %>%
    group_by(cluster_label) %>%
    summarise(val = mean(.data[[var]], na.rm = TRUE),
              sd = sd(.data[[var]], na.rm = TRUE),
              .groups = "drop") %>%
    pivot_wider(names_from = cluster_label,
                values_from = c(val, sd),
                names_glue = "{cluster_label}_{.value}") %>%
    mutate(Variable = vars_table1[[var]]) %>%
    select(Variable, everything())
})
print(table1)
write_csv(table1, "../r_output/table1_descriptive.csv")

# National averages
cat("\n=== NATIONAL AVERAGES ===\n")
cat("Total PAF:", round(mean(df$Total_PAF), 2), "%\n")
cat("PM2.5 PAF:", round(mean(df$PM25_PAF), 2), "%\n")
cat("HHD PAF:", round(mean(df$HHD_PAF), 2), "%\n")
cat("O3 PAF:", round(mean(df$O3_PAF), 2), "%\n")

# ------------------------------------------------------------------------------
# 4. SPEARMAN CORRELATIONS
# ------------------------------------------------------------------------------
cat("\n=== SPEARMAN CORRELATIONS ===\n")

pairs <- list(
  c("elevation_m", "PM25_PAF", "Elevation vs PM2.5 PAF"),
  c("elevation_m", "HHD_PAF", "Elevation vs Household PAF"),
  c("elevation_m", "Total_PAF", "Elevation vs Total PAF"),
  c("elevation_m", "O3_PAF", "Elevation vs O3 PAF"),
  c("elevation_m", "COPD_DALY_rate", "Elevation vs COPD DALY"),
  c("HHD_PAF", "COPD_DALY_rate", "Household PAF vs COPD DALY")
)

corr_results <- map_dfr(pairs, function(p) {
  r <- cor(df[[p[1]]], df[[p[2]]], method = "spearman", use = "complete.obs")
  # Approximate p-value using t-distribution
  n <- sum(complete.cases(df[c(p[1], p[2])]))
  t_stat <- r * sqrt((n - 2) / (1 - r^2))
  pval <- 2 * pt(-abs(t_stat), df = n - 2)
  tibble(Comparison = p[3], Spearman_r = round(r, 3),
         p_value = ifelse(pval >= 0.001, sprintf("%.4f", pval), "<0.001"))
})
print(corr_results)
write_csv(corr_results, "../r_output/correlations.csv")

# ------------------------------------------------------------------------------
# 5. COVARIATE-ADJUSTED ROBUST REGRESSION (HC3)
# ------------------------------------------------------------------------------
cat("\n=== ROBUST REGRESSION (HC3) ===\n")

# Standardize variables
vars_std <- c("elevation_m", "HHD_PAF", "gdp_pc", "urban", "beds_per_1000")
df_std <- df %>%
  mutate(across(all_of(vars_std), ~ scale(.)[,1]))

model_ols <- lm(HHD_PAF ~ elevation_m + gdp_pc + urban + beds_per_1000,
                data = df_std)

# HC3 robust standard errors
library(lmtest)
library(sandwich)
robust_se <- coeftest(model_ols, vcov = vcovHC(model_ols, type = "HC3"))
print(robust_se)

reg_results <- tidy(coeftest(model_ols, vcov = vcovHC(model_ols, type = "HC3"))) %>%
  mutate(term = c("(Intercept)", "elevation_m", "gdp_pc", "urban", "beds_per_1000"))
print(reg_results)
write_csv(reg_results, "../r_output/regression_results.csv")

# ------------------------------------------------------------------------------
# 6. CHAIN MEDIATION ANALYSIS
# ------------------------------------------------------------------------------
cat("\n=== CHAIN MEDIATION ANALYSIS ===\n")

vars_med <- c("elevation_m", "HHD_PAF", "COPD_DALY_rate", "gdp_pc", "urban", "beds_per_1000")
df_med <- df %>%
  mutate(across(all_of(vars_med), ~ scale(.)[,1]))

X <- df_med$elevation_m
M <- df_med$HHD_PAF
Y <- df_med$COPD_DALY_rate
C <- df_med[, c("gdp_pc", "urban", "beds_per_1000")]

# Path a: X -> M | C
model_a <- lm(M ~ X + gdp_pc + urban + beds_per_1000, data = df_med)
a <- coef(model_a)["X"]
se_a <- sqrt(vcovHC(model_a, type = "HC3")["X", "X"])

# Path b: M -> Y | X, C
model_b <- lm(Y ~ M + X + gdp_pc + urban + beds_per_1000, data = df_med)
b <- coef(model_b)["M"]
se_b <- sqrt(vcovHC(model_b, type = "HC3")["M", "M"])

# Total effect c: X -> Y | C
model_c <- lm(Y ~ X + gdp_pc + urban + beds_per_1000, data = df_med)
c <- coef(model_c)["X"]

# Direct effect c': X in model_b
cp <- coef(model_b)["X"]
se_cp <- sqrt(vcovHC(model_b, type = "HC3")["X", "X"])

indirect <- a * b
prop_med <- indirect / c

cat(sprintf("Path a = %.3f, SE = %.3f\n", a, se_a))
cat(sprintf("Path b = %.3f, SE = %.3f\n", b, se_b))
cat(sprintf("Total c = %.3f\n", c))
cat(sprintf("Direct c' = %.3f, SE = %.3f\n", cp, se_cp))
cat(sprintf("Indirect = %.3f\n", indirect))
cat(sprintf("Proportion mediated = %.1f%%\n", prop_med * 100))

# Bootstrap CI
n <- nrow(df_med)
n_boot <- 10000
boot_indirect <- numeric(n_boot)

for(i in 1:n_boot) {
  idx <- sample(n, n, replace = TRUE)
  d_i <- df_med[idx, ]
  tryCatch({
    ma_i <- lm(HHD_PAF ~ elevation_m + gdp_pc + urban + beds_per_1000, data = d_i)
    a_i <- coef(ma_i)["elevation_m"]
    mb_i <- lm(COPD_DALY_rate ~ HHD_PAF + elevation_m + gdp_pc + urban + beds_per_1000, data = d_i)
    b_i <- coef(mb_i)["HHD_PAF"]
    boot_indirect[i] <- a_i * b_i
  }, error = function(e) boot_indirect[i] <- NA)
}

boot_indirect <- na.omit(boot_indirect)
ci_lower <- quantile(boot_indirect, 0.025)
ci_upper <- quantile(boot_indirect, 0.975)
cat(sprintf("Bootstrap 95%% CI: [%.3f, %.3f]\n", ci_lower, ci_upper))

# Sobel test
sobel_se <- sqrt(a^2 * se_b^2 + b^2 * se_a^2)
sobel_z <- indirect / sobel_se
sobel_p <- 2 * (1 - pnorm(abs(sobel_z)))
cat(sprintf("Sobel: z = %.2f, p = %.3f\n", sobel_z, sobel_p))

mediation_out <- list(
  path_a = list(coef = a, se = se_a),
  path_b = list(coef = b, se = se_b),
  total_c = c,
  direct_cp = list(coef = cp, se = se_cp),
  indirect = indirect,
  prop_mediated = prop_med,
  bootstrap_ci = c(ci_lower, ci_upper),
  sobel = list(z = sobel_z, p = sobel_p)
)
write_json(mediation_out, "../r_output/mediation_results.json")

# ------------------------------------------------------------------------------
# 7. SPATIAL AUTOCORRELATION (Moran's I)
# ------------------------------------------------------------------------------
cat("\n=== GLOBAL MORAN'S I ===\n")

# Provincial capital coordinates
coords_df <- tribble(
  ~province, ~lat, ~lon,
  "Beijing", 39.9, 116.4, "Tianjin", 39.1, 117.2, "Hebei", 38.0, 114.5,
  "Shanxi", 37.9, 112.3, "Inner Mongolia", 43.7, 111.7, "Liaoning", 41.8, 123.4,
  "Jilin", 43.7, 126.2, "Heilongjiang", 47.0, 128.0, "Shanghai", 31.2, 121.5,
  "Jiangsu", 32.1, 118.8, "Zhejiang", 29.2, 120.2, "Anhui", 31.9, 117.3,
  "Fujian", 26.1, 119.3, "Jiangxi", 27.6, 115.9, "Shandong", 36.7, 117.0,
  "Henan", 34.0, 113.7, "Hubei", 30.6, 114.3, "Hunan", 27.7, 111.7,
  "Guangdong", 23.4, 113.4, "Guangxi", 23.8, 108.3, "Hainan", 19.0, 109.5,
  "Chongqing", 29.6, 106.5, "Sichuan", 30.7, 102.9, "Guizhou", 26.6, 106.7,
  "Yunnan", 25.0, 102.7, "Shaanxi", 35.9, 109.2, "Gansu", 36.1, 103.8,
  "Qinghai", 36.6, 101.8, "Ningxia", 38.5, 106.3, "Xinjiang", 43.8, 87.6,
  "Tibet", 29.6, 91.1
)

df_spatial <- df %>% left_join(coords_df, by = "province")

# Build k-NN weights (k=4)
make_knn_weights <- function(coords, k = 4) {
  n <- nrow(coords)
  dist_mat <- as.matrix(dist(coords))
  diag(dist_mat) <- Inf
  W <- matrix(0, n, n)
  for(i in 1:n) {
    nearest <- order(dist_mat[i, ])[1:k]
    W[i, nearest] <- 1 / k
  }
  W
}

coord_mat <- as.matrix(df_spatial[, c("lat", "lon")])
W <- make_knn_weights(coord_mat, k = 4)

morans_i <- function(values, W) {
  n <- length(values)
  z <- values - mean(values)
  denom <- sum(z^2)
  num <- sum(W * outer(z, z))
  I <- (n / sum(W)) * num / denom
  return(I)
}

moran_perm <- function(values, W, n_perm = 999) {
  I_obs <- morans_i(values, W)
  I_perm <- replicate(n_perm, {
    z_perm <- sample(values - mean(values))
    n <- length(values)
    num <- sum(W * outer(z_perm, z_perm))
    (n / sum(W)) * num / sum(z_perm^2)
  })
  p_val <- (sum(I_perm >= I_obs) + 1) / (n_perm + 1)
  list(I = I_obs, p = p_val, I_perm = I_perm)
}

metrics <- c("HHD_PAF" = "Household PAF",
             "PM25_PAF" = "PM2.5 PAF",
             "Total_PAF" = "Total PAF")

spatial_results <- map(names(metrics), function(m) {
  vals <- df_spatial[[m]]
  res <- moran_perm(vals, W, n_perm = 999)
  cat(sprintf("%s: Moran's I = %.3f, p = %.3f\n", metrics[m], res$I, res$p))
  res
})
names(spatial_results) <- names(metrics)

saveRDS(spatial_results, "../r_output/spatial_autocorrelation.rds")

cat("\n=== ANALYSIS COMPLETE ===\n")
cat("Outputs saved to ../r_output/\n")
