# ==============================================================================
# 07_figure6.R
# ==============================================================================
# Figure 5: Covariate-Adjusted Chain Mediation
# Panel A: Pathway diagram
# Panel B: COPD DALY Rate vs. Elevation scatter plot
# 修改：
#   1. 图A绿色框放大，a/c'左移，b右移，所有字体小四
#   2. 图B横纵坐标和图例字体小四、纯黑加粗
# ==============================================================================

library(tidyverse)

set.seed(42)

df <- read_csv("../data/analysis_provinces_31.csv", show_col_types = FALSE)

# Cluster colors
lowland_provs <- c("Shanghai", "Tianjin", "Zhejiang", "Beijing", "Jiangsu", "Hainan",
                   "Guangdong", "Fujian", "Hubei", "Hunan", "Shandong", "Hebei",
                   "Ningxia", "Jilin", "Liaoning", "Shanxi")
mid_provs <- c("Shaanxi", "Henan", "Anhui", "Inner Mongolia", "Heilongjiang",
               "Jiangxi", "Chongqing", "Sichuan", "Xinjiang", "Guangxi", "Guizhou")
high_provs <- c("Yunnan", "Gansu", "Tibet", "Qinghai")

df <- df %>%
  mutate(cluster_label = case_when(
    province %in% lowland_provs ~ "Lowland",
    province %in% mid_provs ~ "Mid-elevation",
    province %in% high_provs ~ "High-elevation"
  ),
  cluster_label = factor(cluster_label,
                         levels = c("Lowland", "Mid-elevation", "High-elevation")))

cluster_colors <- c("Lowland" = "#4CAF50", "Mid-elevation" = "#9C27B0", "High-elevation" = "#FF9800")

# ------------------------------------------------------------------------------
# PANEL A: Mediation pathway diagram
# ------------------------------------------------------------------------------
pA <- ggplot() +
  coord_cartesian(xlim = c(0, 10), ylim = c(-1.2, 10)) +
  theme_void() +
  labs(title = "A. Covariate-Adjusted Chain Mediation") +
  theme(plot.title = element_text(face = "bold", size = 14, hjust = 0.5, color = "#000000")) +
  # Nodes
  annotate("rect", xmin = 0.2, xmax = 2.8, ymin = 4, ymax = 6,
           fill = "#B8E6F0", color = "#1565C0", linewidth = 1) +
  annotate("text", x = 1.5, y = 5, label = "Elevation\n(X)", size = 3.5, fontface = "bold", color = "#000000") +

  annotate("rect", xmin = 3.8, xmax = 6.2, ymin = 7, ymax = 9,
           fill = "#FFE4B5", color = "#E65100", linewidth = 1) +
  annotate("text", x = 5, y = 8, label = "Household Solid\nFuel PAF (M)", size = 3.5, fontface = "bold", color = "#000000") +

  annotate("rect", xmin = 3.8, xmax = 6.2, ymin = 0.5, ymax = 2.5,
           fill = "#E8E8E8", color = "#333333", linewidth = 1) +
  annotate("text", x = 5, y = 1.5, label = "Covariates (C)\nGDP, Urban, Beds", size = 3.5, color = "#000000") +

  annotate("rect", xmin = 7.2, xmax = 9.8, ymin = 4, ymax = 6,
           fill = "#FFB6C1", color = "#C62828", linewidth = 1) +
  annotate("text", x = 8.5, y = 5, label = "COPD DALY\nRate (Y)", size = 3.5, fontface = "bold", color = "#000000") +
  # Path a（a左移）
  annotate("segment", x = 2.8, xend = 3.8, y = 5.5, yend = 7.5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#2E7D32", linewidth = 1) +
  annotate("text", x = 2.3, y = 7.2, label = "a = 0.412*", size = 3.5,
           color = "#2E7D32", fontface = "bold", hjust = 0) +
  # Path b（b右移）
  annotate("segment", x = 6.2, xend = 7.2, y = 7.5, yend = 5.5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#2E7D32", linewidth = 1) +
  annotate("text", x = 7.7, y = 7.2, label = "b = 0.548*", size = 3.5,
           color = "#2E7D32", fontface = "bold", hjust = 1) +
  # Path c'（c'左移）
  annotate("segment", x = 2.8, xend = 7.2, y = 5, yend = 5,
           arrow = arrow(length = unit(0.3, "cm")), color = "#1565C0", linewidth = 1) +
  annotate("text", x = 4.2, y = 4.3, label = "c' = 0.230*", size = 3.5,
           color = "#1565C0", fontface = "bold", hjust = 0.5) +
  # Covariate arrows (dashed)
  annotate("segment", x = 5, xend = 5, y = 2.5, yend = 7,
           arrow = arrow(length = unit(0.2, "cm")), color = "#888888",
           linewidth = 1, linetype = "dashed") +
  annotate("segment", x = 5, xend = 7.2, y = 2.5, yend = 4.5,
           arrow = arrow(length = unit(0.2, "cm")), color = "#888888",
           linewidth = 1, linetype = "dashed") +
  # Summary box（放大绿色框，避免文字溢出）
  annotate("rect", xmin = 0.2, xmax = 9.8, ymin = -1.5, ymax = -0.2,
           fill = "#E8F5E9", color = "#2E7D32", linewidth = 1.2) +
  annotate("text", x = 5, y = -0.85,
           label = "Indirect effect (a x b) = +0.226    |    Bootstrap 95% CI: [0.015, 0.546]    |    49.5% mediated",
           size = 3.5, color = "#2E7D32", fontface = "bold")

# ------------------------------------------------------------------------------
# PANEL B: COPD DALY vs Elevation scatter plot
# ------------------------------------------------------------------------------
key_provinces <- c("Tibet", "Qinghai", "Yunnan", "Gansu", "Shanghai", "Beijing")

pB <- ggplot(df, aes(x = elevation_m, y = COPD_DALY_rate, color = cluster_label)) +
  geom_point(size = 3.5, alpha = 0.85) +
  geom_smooth(method = "loess", se = FALSE, color = "black", linetype = "dashed", linewidth = 0.8) +
  geom_smooth(method = "lm", se = FALSE, color = "red", alpha = 0.4, linewidth = 0.8) +
  geom_text(data = df %>% filter(province %in% key_provinces),
            aes(label = province), hjust = -0.15, vjust = -0.3,
            size = 3.5, fontface = "bold", show.legend = FALSE) +
  scale_color_manual(values = cluster_colors,
                     name = NULL,
                     labels = c("Lowland (n=16)", "Mid-elevation (n=11)", "High-elevation (n=4)")) +
  labs(x = "Population-Weighted Mean Elevation (m)",
       y = "COPD Age-Standardized DALY Rate (per 100,000)",
       title = "B. COPD DALY Rate vs. Elevation") +
  annotate("text", x = Inf, y = -Inf,
           label = sprintf("Pearson r = %.3f, p < 0.001",
                           cor(df$elevation_m, df$COPD_DALY_rate, method = "pearson")),
           hjust = 1, vjust = -0.5, size = 3.5,
           color = "black", fontface = "bold") +
  theme_bw(base_size = 10) +
  theme(plot.title       = element_text(face = "bold", size = 14, color = "#000000"),
        axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
        axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
        legend.position  = "bottom",
        legend.text      = element_text(size = 14, face = "bold", color = "#000000")) +
  xlim(-200, 5200) + ylim(1050, 1600)

# Combine
combined <- pA + pB + plot_layout(ncol = 2, widths = c(1, 1.2))

out_path <- "D:/指导的学生/研究生/侯永强/投稿稿件和图表_修订版R语言/submission/reproducibility_package/reproducibility/r_output/figures"
dir.create(out_path, showWarnings = FALSE, recursive = TRUE)

ggsave(paste0(out_path, "/Figure5_Mediation_Pathway.png"),
       combined, width = 16, height = 7.5, dpi = 300, bg = "white")
cat("Saved:", out_path, "/Figure5_Mediation_Pathway.png\n")