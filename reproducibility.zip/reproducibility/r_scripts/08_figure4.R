# ==============================================================================
# 08_figure4.R
# ==============================================================================
# Figure 4: Global Moran's I Permutation Distributions
# Three panels: Household PAF, PM2.5 PAF, Total PAF
# 修改：
#   1. A/C图r/p标注右移避免被框截断
#   2. B图标注往左移
#   3. ABC三图横纵坐标和名称字体小四、纯黑加粗
# ==============================================================================

library(tidyverse)

set.seed(42)

df <- read_csv("../data/analysis_provinces_31.csv", show_col_types = FALSE)

# Provincial capital coordinates
coords_df <- tribble(
  ~province, ~lat, ~lon,
  "Beijing", 39.9, 116.4, "Tianjin", 39.1, 117.2, "Hebei", 38.0, 114.5,
  "Shanxi", 37.9, 112.3, "Inner Mongolia", 43.7, 111.7, "Liaoning", 41.8, 123.4,
  "Jilin", 43.7, 126.2, "Heilongjiang", 47.0, 128.0, "Shanghai", 31.2, 121.5,
  "Jiangsu", 32.1, 118.8, "Zhejiang", 29.2, 120.2, "Anhui", 31.9, 117.3,
  "Fujian", 26.1, 119.3, "Jiangxi", 27.6, 115.9, "Shandong", 36.7, 117.0,
  "Henan", 34.0, 113.7, "Hubei", 30.6, 114.3, "Hunan", 27.7, 111.7,
  "Guangdong", 23.4, 113.4, "Guangxi", 23.8, 108.3, "Hainan", 19.0, 109.5,
  "Chongqing", 29.6, 106.5, "Sichuan", 30.7, 102.9, "Guizhou", 26.6, 106.7,
  "Yunnan", 25.0, 102.7, "Shaanxi", 35.9, 109.2, "Gansu", 36.1, 103.8,
  "Qinghai", 36.6, 101.8, "Ningxia", 38.5, 106.3, "Xinjiang", 43.8, 87.6,
  "Tibet", 29.6, 91.1
)

df_spatial <- df %>% left_join(coords_df, by = "province")

# Build k-NN weights (k=4)
make_knn_weights <- function(coords, k = 4) {
  n <- nrow(coords)
  dist_mat <- as.matrix(dist(coords))
  diag(dist_mat) <- Inf
  W <- matrix(0, n, n)
  for(i in 1:n) {
    nearest <- order(dist_mat[i, ])[1:k]
    W[i, nearest] <- 1 / k
  }
  W
}

coord_mat <- as.matrix(df_spatial[, c("lat", "lon")])
W <- make_knn_weights(coord_mat, k = 4)

morans_i <- function(values, W) {
  n <- length(values)
  z <- values - mean(values)
  denom <- sum(z^2)
  num <- sum(W * outer(z, z))
  I <- (n / sum(W)) * num / denom
  return(I)
}

moran_perm <- function(values, W, n_perm = 999) {
  I_obs <- morans_i(values, W)
  I_perm <- replicate(n_perm, {
    z_perm <- sample(values - mean(values))
    n <- length(values)
    num <- sum(W * outer(z_perm, z_perm))
    (n / sum(W)) * num / sum(z_perm^2)
  })
  p_val <- (sum(I_perm >= I_obs) + 1) / (n_perm + 1)
  list(I = I_obs, p = p_val, I_perm = I_perm)
}

# Generate plots for each metric
metrics <- c("HHD_PAF" = "A. Household Solid Fuel PAF",
             "PM25_PAF" = "B. Ambient PM2.5 PAF",
             "Total_PAF" = "C. Total Air Pollution PAF")

plot_list <- map(names(metrics), function(m) {
  vals <- df_spatial[[m]]
  res <- moran_perm(vals, W, n_perm = 999)

  perm_df <- data.frame(I_perm = res$I_perm)

  # 标注x坐标：B图(PM25_PAF)往左移，A/C图保持右侧
  label_x <- if (m == "PM25_PAF") max(perm_df$I_perm) * 0.35 else max(perm_df$I_perm) * 0.75

  ggplot(perm_df, aes(x = I_perm)) +
    geom_histogram(aes(y = after_stat(density)), bins = 30,
                   fill = "#90CAF9", color = "#1565C0", alpha = 0.7) +
    geom_density(color = "#1565C0", linewidth = 1) +
    geom_vline(xintercept = res$I, color = "#C62828", linewidth = 1.5, linetype = "solid") +
    annotate("text",
             x = label_x,
             y = Inf,
             label = sprintf("Observed\nI = %.3f\np = %.3f", res$I, res$p),
             hjust = 0, vjust = 1.5, size = 3.5,
             color = "#C62828", fontface = "bold") +
    labs(x = "Moran's I", y = "Density",
         title = metrics[m]) +
    theme_bw(base_size = 10) +
    theme(plot.title       = element_text(face = "bold", size = 14, color = "#000000"),
          axis.title       = element_text(size = 14, face = "bold", color = "#000000"),
          axis.text        = element_text(size = 14, face = "bold", color = "#000000"),
          panel.grid.minor = element_blank())
})

combined <- wrap_plots(plot_list, ncol = 3) +
  plot_annotation(title = "Figure 4. Global Moran's I Permutation Distributions (999 permutations, k=4 NN weights)",
                  theme = theme(plot.title = element_text(face = "bold", size = 14, color = "#000000")))

out_path <- "D:/指导的学生/研究生/侯永强/投稿稿件和图表_修订版R语言/submission/reproducibility_package/reproducibility/r_output/figures"
dir.create(out_path, showWarnings = FALSE, recursive = TRUE)

ggsave(paste0(out_path, "/Figure4_Spatial_Autocorrelation.png"),
       combined, width = 16, height = 5.5, dpi = 300, bg = "white")
cat("Saved:", out_path, "/Figure4_Spatial_Autocorrelation.png\n")